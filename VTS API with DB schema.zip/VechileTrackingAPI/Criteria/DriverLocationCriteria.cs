﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VechileTrackingRestAPI.Criteria
{
    public class DriverLocationCriteria
    {
        public Int64 DriverId { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string VechileNumber { get; set; }
        public string WatcherId { get; set; }
    }
}