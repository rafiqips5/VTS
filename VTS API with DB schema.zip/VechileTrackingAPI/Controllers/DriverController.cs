﻿using log4net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Reflection;
using System.Threading.Tasks;
using VechileTrackingAPI.Models;
using VechileTrackingAPI.Service;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Controllers
{
    [Route("[Controller]")]
    [Authorize]
    public class DriverController : Controller
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private ICreateDriverService _createDriverService;
        public DriverController(ICreateDriverService createDriverService)
        {
            _createDriverService = createDriverService;
        }

        [HttpPost]
        [Route("CreateDriver")]
        public async Task<IActionResult> CreateDriver([FromBody] DriverInformationModel driverInformationModel)
        {
            try
            {
                if (driverInformationModel != null)
                {
                    log.InfoFormat("Creating driver profile for driver {0}",driverInformationModel.Name);
                    DriverInfoResponseModel driverInfoResponseModel = await Task.FromResult(_createDriverService.RegisterDriver(driverInformationModel));
                    log.InfoFormat("Creating driver profile for driver {0} is success", driverInformationModel.Name);

                    return Ok(driverInfoResponseModel);
                }
                else
                {
                    log.InfoFormat("object is null");
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while creating the user : {0}", ex);
                return StatusCode(StatusCodes.Status500InternalServerError);

            }
        }
    }
}
