﻿using VechileTrackingAPI.Models;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Service
{
    public interface ICreateDriverService
    {
        DriverInfoResponseModel RegisterDriver(DriverInformationModel driverInformationModel );
    }
}
