﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace VechileTrackingRestAPI.Models.Response
{
    public class UserDetailsBasedOnUserId
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Roles { get; set; }
        public string UserId { get; set; }
        public bool IsValidToken { get; set; }
    }
}