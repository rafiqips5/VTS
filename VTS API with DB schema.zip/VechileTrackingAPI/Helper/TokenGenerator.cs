﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingRestAPI.Helper
{
    public static class TokenGenerator
    {

        public static string GenerateToken(LoginResponseModel loginResponseModel)
        {
            var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            string key = config["APISecretKey:Key"];

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256Signature);

            var header = new JwtHeader(credentials);

            //Some PayLoad that contain information about the  customer information
            var payloadJwt = new JwtPayload
           {
               { "UserName ", loginResponseModel.UserName},
               { "Roles", loginResponseModel.Roles},
               { "UserId",loginResponseModel.UserId},
               { "EmailID",loginResponseModel.Email}
           };

            var secToken = new JwtSecurityToken(header, payloadJwt);
            var handler = new JwtSecurityTokenHandler();
            var tokenString = handler.WriteToken(secToken);

            return tokenString;
        }

        public static UserDetailsBasedOnUserId ValidateToken(string token)
        {
            UserDetailsBasedOnUserId userDetailsBasedOnUserId = new UserDetailsBasedOnUserId();
            try
            {
                var handler = new JwtSecurityTokenHandler();
                var parsedToken = handler.ReadJwtToken(token);
                Dictionary<string, string> tokenData = new Dictionary<string, string>();

                //DatabaseOperations databaseOperations = new DatabaseOperations();
                //foreach (Claim claimsData in parsedToken.Claims)
                //{
                //    if (claimsData.Type == "UserId")
                //    {
                //        userDetailsBasedOnUserId = databaseOperations.GetUserBasedOnUserId(claimsData.Value);
                //        tokenData.Add(claimsData.Type, claimsData.Value);
                //    }
                //    else
                //    {
                //        tokenData.Add(claimsData.Type, claimsData.Value);
                //    }
                //}
                //if (userDetailsBasedOnUserId != null && tokenData.ContainsValue(userDetailsBasedOnUserId.UserName) &&
                //    tokenData.ContainsValue(userDetailsBasedOnUserId.UserName) && tokenData.ContainsValue(userDetailsBasedOnUserId.Roles) &&
                //    tokenData.ContainsValue(userDetailsBasedOnUserId.Email))
                //{
                //    userDetailsBasedOnUserId.IsValidToken = true;
                //}
            }
            catch (Exception ex)
            {
                return userDetailsBasedOnUserId = null;
            }
            return userDetailsBasedOnUserId;
        }
    }
}