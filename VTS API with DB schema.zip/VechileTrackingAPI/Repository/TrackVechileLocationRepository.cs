﻿using log4net;
using System;
using System.Linq;
using System.Net;
using System.Reflection;

using VechileTrackingAPI.Models;
using VechileTrackingAPI.Service;
using VechileTrackingRestAPI.Helper;
using VechileTrackingRestAPI.Models.Response;


namespace VechileTrackingAPI.Repository
{

    public class TrackVechileLocationRepository : ITrackVechileLocation
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        VechileDBContext vechileDBContext = null;
        DriverLocationResponseModel driverLocationResponseModel = null;

        public DriverLocationResponseModel TrackVechileLocation(VechileLocationModel vechileLocationModel)
        {
            try
            {
                driverLocationResponseModel = new DriverLocationResponseModel();

                if (string.IsNullOrEmpty(vechileLocationModel.DriverId.ToString()))
                {
                    log.Info("DriverId is empty, please enter the value.");
                    driverLocationResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverLocationResponseModel.StatusDescription = "DriverId is empty, please enter the value.";
                    return driverLocationResponseModel;
                }

                if (string.IsNullOrEmpty(vechileLocationModel.Latitude))
                {
                    log.Info("Latitude is empty, please enter the value.");
                    driverLocationResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverLocationResponseModel.StatusDescription = "Latitude is empty, please enter the value.";
                    return driverLocationResponseModel;
                }

                if (string.IsNullOrEmpty(vechileLocationModel.Longitude))
                {
                    log.Info("Longitude is empty, please enter the value.");
                    driverLocationResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverLocationResponseModel.StatusDescription = "Longitude is empty, please enter the value.";
                    return driverLocationResponseModel;
                }
                if (string.IsNullOrEmpty(vechileLocationModel.WatcherId.ToString()))
                {
                    log.Info("WatcherId is empty, please enter the value.");
                    driverLocationResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverLocationResponseModel.StatusDescription = "WatcherId is empty, please enter the value.";
                    return driverLocationResponseModel;
                }
                if (string.IsNullOrEmpty(vechileLocationModel.VechileNumber))
                {
                    log.Info("VechileNumber is empty, please enter the value.");
                    driverLocationResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverLocationResponseModel.StatusDescription = "VechileNumber is empty, please enter the value.";
                    return driverLocationResponseModel;
                }

                vechileDBContext = new VechileDBContext();

                int driverCount = vechileDBContext.TblDriverInformations.Where(d => d.DriverId == vechileLocationModel.DriverId).Count();
                int vechileCount = vechileDBContext.TblVechileInformations.Where(v => v.Number == vechileLocationModel.VechileNumber).Count();

                if (driverCount == 0 || vechileCount == 0)
                {
                    log.InfoFormat("driverCount : {0} or vechileCount{1} are not available",driverCount,vechileCount);
                    driverLocationResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverLocationResponseModel.StatusDescription = "Driver Id or Vechile ID is not found";
                    return driverLocationResponseModel;
                }

                else
                {
                    // inserting the data into database
                    vechileLocationModel.DateTime = DateTime.Now;
                    var data = vechileDBContext.TblDriverLocations.Add(vechileLocationModel);
                    vechileDBContext.SaveChanges();

                    log.InfoFormat("Vechile sucessfully tracked for driver {0}",vechileLocationModel.DriverId);
                    driverLocationResponseModel = new DriverLocationResponseModel();
                    driverLocationResponseModel.StatusCode = HttpStatusCode.OK;
                    driverLocationResponseModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.SUCCESS.ToString();
                    return driverLocationResponseModel;
                }
            }
            catch (Exception ex)
            {
                log.InfoFormat("Exeception Occured while tracking the vechile id:{0} , Error is {1}",vechileLocationModel.DriverId,ex);
                driverLocationResponseModel = new DriverLocationResponseModel();
                driverLocationResponseModel.StatusCode = HttpStatusCode.InternalServerError;
                driverLocationResponseModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.INNTERNAL_SERVER_ERROR.ToString(); 
                return driverLocationResponseModel;
            }

        }
    }
}
