﻿using log4net;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using VechileTrackingAPI.Helper.Authentication;
using VechileTrackingAPI.Models;
using VechileTrackingAPI.Service.UserService;
using VechileTrackingRestAPI.Helper;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Repository.User
{ 
    public class UserRegistrationRepositary : IUserRegisteration
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly IConfiguration _configuration;

        VechileDBContext vechileDBContext = null;

        public UserRegistrationRepositary(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager, IConfiguration configuration)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
            _configuration = configuration;
        }

        public async Task<CreateNewUserResponseModel> CreateNewUserAsync(UserModel userModel)
        {
            CreateNewUserResponseModel createNewUserResponseModel = null;
            string errorDesc = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(userModel.UserName))
                {
                    log.Info("user id is empty");
                    createNewUserResponseModel = new CreateNewUserResponseModel();
                    createNewUserResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createNewUserResponseModel.StatusDescription = "User Name is empty. enter the user name";
                    return  createNewUserResponseModel;
                }
                if(string.IsNullOrEmpty(userModel.UserPassword))
                {
                    log.Info("user password is empty");
                    createNewUserResponseModel = new CreateNewUserResponseModel();
                    createNewUserResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createNewUserResponseModel.StatusDescription = "User password is empty. enter the valid password";
                    return createNewUserResponseModel;
                }
                if(string.IsNullOrEmpty(userModel.UserEmailId))
                {
                    log.Info("user email id is empty");
                    createNewUserResponseModel = new CreateNewUserResponseModel();
                    createNewUserResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createNewUserResponseModel.StatusDescription = "User email id is empty. enter the email id";
                    return createNewUserResponseModel;
                }
                if(string.IsNullOrEmpty(userModel.UserRoles))
                {
                    log.Info("user id is empty");
                    createNewUserResponseModel = new CreateNewUserResponseModel();
                    createNewUserResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createNewUserResponseModel.StatusDescription = "User Role is empty. enter the user name";
                    return createNewUserResponseModel;
                }

                var userExists = await userManager.FindByNameAsync(userModel.UserName);
                if (userExists != null)
                {
                    createNewUserResponseModel = new CreateNewUserResponseModel();
                    createNewUserResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createNewUserResponseModel.StatusDescription = "User name is already exist";
                    return createNewUserResponseModel;
                }

                ApplicationUser user = new ApplicationUser()
                {
                    Email = userModel.UserEmailId,
                    SecurityStamp = Guid.NewGuid().ToString(),
                    UserName = userModel.UserName,
                    Id = Guid.NewGuid().ToString()
                };

                // Creating user in the aspnet user table. 
                var result = await userManager.CreateAsync(user, userModel.UserPassword);
                
                if (!result.Succeeded)
                {
                    log.Info("Error occured while adding the user into the usermanager");
                    createNewUserResponseModel = new CreateNewUserResponseModel();
                    foreach (var error in result.Errors)
                    {
                        errorDesc += error.Description + "|";
                    }                    
                    createNewUserResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createNewUserResponseModel.StatusDescription = errorDesc;
                    return createNewUserResponseModel;
                }
                else
                {
                    // creating user role
                    if (!await roleManager.RoleExistsAsync(UserRoles.Admin) && userModel.UserRoles.ToLower() == "admin")
                    {
                        log.Info("Creating admin role");
                        await roleManager.CreateAsync(new IdentityRole(UserRoles.Admin));
                        log.Info("Creating admin role is success");
                    }
                    if (!await roleManager.RoleExistsAsync(UserRoles.User) && userModel.UserRoles.ToLower() == "user")
                    {
                        log.Info("Creating User role");
                        await roleManager.CreateAsync(new IdentityRole(UserRoles.User));
                        log.Info("Creating User role is success");
                    }
                    // adding roles for user
                    if (await roleManager.RoleExistsAsync(UserRoles.Admin) && userModel.UserRoles.ToLower() == "admin")
                    {
                        log.Info("adding admin role");
                        await userManager.AddToRoleAsync(user, UserRoles.Admin);
                        log.Info("adding admin role is success");
                    }
                    else
                    {
                        log.Info("adding user role");
                        await userManager.AddToRoleAsync(user, UserRoles.User);
                        log.Info("adding user role is success");
                    }
                    // encryting password
                    var encrtypedPassword = Encoding.UTF8.GetBytes(userModel.UserPassword);
                    userModel.UserPassword = Convert.ToBase64String(encrtypedPassword);
                    userModel.CreatedDate = DateTime.Now;

                    //Adding user details in master table for upcomming work
                    createNewUserResponseModel = new CreateNewUserResponseModel();
                    createNewUserResponseModel.UserId = userModel.UserName;

                    userModel.UserId = userModel.UserName ;
                    // user added in user master for customization
                    vechileDBContext = new VechileDBContext();
                    vechileDBContext.TblUserMasters.Add(userModel);
                    vechileDBContext.SaveChanges();
                    log.InfoFormat("User has been successfully registered for {0}", userModel.UserId);

                    //Creating response
                   
                    createNewUserResponseModel.StatusCode = HttpStatusCode.OK;
                    createNewUserResponseModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.SUCCESS.ToString();

                     return createNewUserResponseModel;
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Error occured while processing the request {0}", ex);
                createNewUserResponseModel = new CreateNewUserResponseModel();
                createNewUserResponseModel.StatusCode = HttpStatusCode.InternalServerError;
                createNewUserResponseModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.INNTERNAL_SERVER_ERROR.ToString();
                return createNewUserResponseModel;
            }
        }
    }
}
