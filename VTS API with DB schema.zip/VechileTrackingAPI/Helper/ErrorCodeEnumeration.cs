﻿namespace VechileTrackingRestAPI.Helper
{
    public static class ErrorCodeEnumeration
    {
        public  enum ResponseDescription
        {
            SUCCESS,
            FAILURE,
            ERROR,
            INTERNAL_ERROR,
            INVALID_INPUT,
            INNTERNAL_SERVER_ERROR,
            CREATED
        }
    }
}