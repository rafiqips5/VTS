﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace VechileTrackingRestAPI.Models.Response
{
    public class CreateVechileResponseModel
    {       
        public HttpStatusCode StatusCode { get; set; }
        public string StatusDescription { get; set; }
    }
}