﻿using System;
using System.Threading.Tasks;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Service
{
    public interface IVechileLocationHistory
    {
        VechileLocationHistoryByDriverIdModel GetVechileLocationHistory(Int64 DriverId);
    }
}
