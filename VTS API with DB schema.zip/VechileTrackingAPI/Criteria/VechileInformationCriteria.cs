﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VechileTrackingRestAPI.Criteria
{
    public class VechileInformationCriteria
    {
        public string DriverId { get; set; }
        public string BrandName { get; set; }
        public string Model { get; set; }
        public string Number { get; set; }
        public string EngineChaseNumber { get; set; }
        public DateTime PurchaseDate { get; set; }
        public string Condition { get; set; }
    }
}