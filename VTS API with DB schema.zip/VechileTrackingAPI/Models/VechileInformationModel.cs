﻿using System;

#nullable disable

namespace VechileTrackingAPI.Models
{
    public partial class VechileInformationModel
    {
        public long DriverId { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Number { get; set; }
        public string EngineChaseNumber { get; set; }
        public DateTime? PurchaseDate { get; set; }
        public string VechileCondition { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual DriverInformationModel Driver { get; set; }
    }
}
