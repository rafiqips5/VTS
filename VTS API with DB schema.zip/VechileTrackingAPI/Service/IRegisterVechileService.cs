﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VechileTrackingAPI.Models;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Service
{
    public interface IRegisterVechileService
    {
        CreateVechileResponseModel RegisterVehicle(VechileInformationModel vechileInformationModel);
    }
}
