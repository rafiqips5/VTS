﻿using log4net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Reflection;
using System.Threading.Tasks;
using VechileTrackingAPI.Models;
using VechileTrackingAPI.Service.UserService;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Controllers
{
    [Route("[Controller]")]
    
    public class UserController : Controller
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private IUserLogin _userLogin;
        private IUserRegisteration _userRegisteration;

        public UserController(IUserLogin userLogin, IUserRegisteration userRegisteration)
        {
            _userLogin = userLogin;
            _userRegisteration = userRegisteration;
        }

        [HttpPost]
        [Route("UserLogin")]
        public async Task<IActionResult> Login([FromBody] UserLoginModel userLoginModel)
        {
            try
            {
                if (userLoginModel == null || string.IsNullOrEmpty(userLoginModel.UserName) || string.IsNullOrEmpty(userLoginModel.Password))
                {
                    log.Info("User name or passowrd are empty");
                    return BadRequest("User name or passowrd are empty");
                }
                else
                {
                    log.InfoFormat("Trying to login for user is {0}",userLoginModel.UserName);
                    LoginResponseModel loginResponseModel = await _userLogin.ValidateUserLoginAsync(userLoginModel);
                    log.InfoFormat("User login is success for username is {0}",userLoginModel.UserName);
                    return Ok(loginResponseModel);
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while creating the user : {0}", ex);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost]
        [Route("UserRegister")]
        public async Task<IActionResult> Register([FromBody] UserModel userModel)
        {
            try
            {
                if (userModel == null)
                {
                    log.InfoFormat("Object is empty");
                    return BadRequest("Data is emmpty");
                }
                else
                {
                    log.InfoFormat("Registration started for user : {0}", userModel.UserName);
                    CreateNewUserResponseModel createNewUserResponseModel = await _userRegisteration.CreateNewUserAsync(userModel);
                    log.InfoFormat("Registration started for user : {0} is success", userModel.UserName);

                    return Ok(createNewUserResponseModel);
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while creating the user : {0}", ex);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }


    }
}
