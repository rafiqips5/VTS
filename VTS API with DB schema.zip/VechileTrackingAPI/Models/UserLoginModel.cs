﻿using System.ComponentModel.DataAnnotations;

namespace VechileTrackingAPI.Models
{
    public class UserLoginModel
    {
        [Required(ErrorMessage = "User Name is required. It's your Email Id")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; }
    }
}
