﻿using log4net;
using System;
using System.Linq;
using System.Net;
using System.Reflection;
using VechileTrackingAPI.Models;
using VechileTrackingAPI.Service;
using VechileTrackingRestAPI.Helper;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Repository
{
    public class CreateDriverRepository : ICreateDriverService
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        VechileDBContext vechileDBContext = null;
        DriverInfoResponseModel driverInfoResponseModel = null;

        public DriverInfoResponseModel RegisterDriver(DriverInformationModel driverInformationModel)
        {
            try
            {
                driverInfoResponseModel = new DriverInfoResponseModel();
                if (string.IsNullOrEmpty(driverInformationModel.Name))
                {
                    log.Info("Name is empty, please enter the value.");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "Name is empty, please enter the value.";
                    return driverInfoResponseModel;
                }

                if (string.IsNullOrEmpty(driverInformationModel.Age.ToString()) || driverInformationModel.Age < 18)
                {
                    log.Info("Age is empty or 18+ is allowed, please enter the value.");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "Age is empty or 18+ is allowed, please enter the value.";
                    return driverInfoResponseModel;
                }

                if (string.IsNullOrEmpty(driverInformationModel.Gender))
                {
                    log.Info("Gender is empty, please enter the value.");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "Gender is empty, please enter the value.";
                    return driverInfoResponseModel;
                }

                if (string.IsNullOrEmpty(driverInformationModel.MobileNumber))
                {
                    log.Info("Mobile Number is empty, please enter the value");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "Mobile Number is empty, please enter the value.";
                    return driverInfoResponseModel;
                }
                if (string.IsNullOrEmpty(driverInformationModel.LicenseNumber))
                {
                    log.Info("Linense Number is empty, please enter the value.");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "Linense Number is empty, please enter the value.";
                    return driverInfoResponseModel;
                }
                if (string.IsNullOrEmpty(driverInformationModel.LicenseValid.ToString()))
                {
                    log.Info("License is empty, please enter the value.");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "License is empty, please enter the value.";
                    return driverInfoResponseModel;
                }
                if (string.IsNullOrEmpty(driverInformationModel.Address1))
                {
                    log.Info("Address1 is empty, please enter the value.");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "Address1 is empty, please enter the value.";
                    return driverInfoResponseModel;
                }
                if (string.IsNullOrEmpty(driverInformationModel.Address2))
                {
                    log.Info("Address2 is empty, please enter the value.");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "Address2 is empty, please enter the value.";
                    return driverInfoResponseModel;
                }
                if (string.IsNullOrEmpty(driverInformationModel.City))
                {
                    log.Info("City is empty, please enter the value");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "City is empty, please enter the value.";
                    return driverInfoResponseModel;
                }
                if (string.IsNullOrEmpty(driverInformationModel.State))
                {
                    log.Info("State is empty, please enter the value.");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "State is empty, please enter the value.";
                    return driverInfoResponseModel;
                }
                if (string.IsNullOrEmpty(driverInformationModel.Country))
                {
                    log.Info("Country is empty, please enter the value.");
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription = "Country is empty, please enter the value.";
                    return driverInfoResponseModel;
                }

                vechileDBContext = new VechileDBContext();
                

                if( vechileDBContext.TblDriverInformations.Where(p => p.MobileNumber == driverInformationModel.MobileNumber).Count() > 0)
                {
                    log.InfoFormat("Creation of driver profile failed due to already registered number :{0}",driverInformationModel.MobileNumber);
                    driverInfoResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    driverInfoResponseModel.StatusDescription += "Mobile Number is already registered,Please provide alternate mobile number ";
                    return driverInfoResponseModel;
                }
                else
                {
                    // adding driver data into database
                    driverInformationModel.DateTime = DateTime.Now;
                    var reponse = vechileDBContext.TblDriverInformations.Add(driverInformationModel);
                    vechileDBContext.SaveChanges();

                    log.InfoFormat("Driver created successfully for the user : {0}",driverInformationModel.Name);
                    // generating response
                    driverInfoResponseModel.CustomerRelationshipNumber = driverInformationModel.DriverId.ToString();
                    driverInfoResponseModel.StatusCode = HttpStatusCode.Created;
                    driverInfoResponseModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.SUCCESS.ToString();
                    return driverInfoResponseModel;
                }

            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while processing data : {0}", ex);
                driverInfoResponseModel.StatusCode = HttpStatusCode.InternalServerError;
                driverInfoResponseModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.INNTERNAL_SERVER_ERROR.ToString();
                return driverInfoResponseModel;
            }
            
        }

    }
}