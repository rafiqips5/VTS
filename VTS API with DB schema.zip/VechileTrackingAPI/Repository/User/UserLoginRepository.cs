﻿using log4net;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using VechileTrackingAPI.Helper.Authentication;
using VechileTrackingAPI.Models;
using VechileTrackingAPI.Service.UserService;
using VechileTrackingRestAPI.Helper;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Repository.User
{
    public class UserLoginRepository : IUserLogin
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly IConfiguration _configuration;

        public UserLoginRepository(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager, IConfiguration configuration)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
            _configuration = configuration;
        }

        public async Task<LoginResponseModel> ValidateUserLoginAsync(UserLoginModel userLoginModel)
        {
            LoginResponseModel loginResponseModel = null;
            try
            {
                log.InfoFormat("Validating the user for {0}",userLoginModel.UserName);
                var user = await userManager.FindByNameAsync(userLoginModel.UserName);
                if (user != null && await userManager.CheckPasswordAsync(user, userLoginModel.Password))
                {
                    log.InfoFormat("Gettings roles for the user : {0}",userLoginModel.UserName);
                    var userRoles = await userManager.GetRolesAsync(user);

                    var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.UserName),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                };

                    foreach (var userRole in userRoles)
                    {
                        authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                    }
                    log.InfoFormat("Roles are added for the user : {0}", userLoginModel.UserName);

                    var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));
                    
                    //Generating JWT Token
                    var token = new JwtSecurityToken(
                        issuer: _configuration["JWT:ValidIssuer"],
                        audience: _configuration["JWT:ValidAudience"],
                        expires: DateTime.Now.AddHours(3),
                        claims: authClaims,
                        signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                        );

                    loginResponseModel = new LoginResponseModel();
                    loginResponseModel.Token = new JwtSecurityTokenHandler().WriteToken(token);
                    loginResponseModel.ValidUpTo = token.ValidTo;
                    loginResponseModel.StatusCode = HttpStatusCode.OK;
                    loginResponseModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.SUCCESS.ToString();
                }
                else
                {
                    log.InfoFormat("Login failed for the user : {0}",userLoginModel.UserName);
                    loginResponseModel = new LoginResponseModel();
                    loginResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    loginResponseModel.StatusDescription = "Invalid UserName or Password";
                }

                return await Task.FromResult(loginResponseModel);
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while processing the Request : {0}",ex);
                loginResponseModel.StatusCode = HttpStatusCode.InternalServerError;
                loginResponseModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.INNTERNAL_SERVER_ERROR.ToString();
                return await Task.FromResult(loginResponseModel);
            }
        }
    }
}

