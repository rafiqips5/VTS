﻿using log4net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Reflection;
using System.Threading.Tasks;

using VechileTrackingAPI.Models;
using VechileTrackingAPI.Service;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Controllers
{
    [Route("[Controller]")]
    [Authorize]
    public class VechileController : Controller
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private IVechileCurrentLocation _vechileCurrentLocation;
        private IRegisterVechileService _registerVechileService;
        private ITrackVechileLocation _trackVechileLocation;
        private IVechileLocationHistory _vechileLocationHistory;


        public VechileController(IVechileCurrentLocation vechileCurrentLocation, IRegisterVechileService registerVechileService,
            ITrackVechileLocation trackVechileLocation, IVechileLocationHistory vechileLocationHistory)
        {
            _vechileCurrentLocation = vechileCurrentLocation;
            _registerVechileService = registerVechileService;
            _trackVechileLocation = trackVechileLocation;
            _vechileLocationHistory = vechileLocationHistory;
        }

        [HttpGet]
        [Route("GetCurrentLocationByDriverID/{DriverId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetVechileLocationByDriverId(Int64 DriverId)
        {
            try
            {
                if (string.IsNullOrEmpty(DriverId.ToString()))
                {
                    log.Info("Driver Id is not supplied");
                    return await Task.FromResult(BadRequest("Driver Id cannot be empty"));
                }
                else
                {
                    log.InfoFormat("Getting currnet location for the vechile for driver id {0}", DriverId);
                    VechileLocationByDriverIdModel response = await Task.FromResult(_vechileCurrentLocation.GetCurrentLocationForVechile(DriverId));
                    log.InfoFormat("Getting currnet location for the vechile for driver id {0} is success", DriverId);
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while creating the user : {0}", ex);
                return StatusCode(StatusCodes.Status500InternalServerError);

            }
        }

        [HttpPost]
        [Route("RegisterVechile")]
        public async Task<IActionResult> RegisterVechileForDriver([FromBody] VechileInformationModel vechileInformationModel)
        {
            try
            {
                if (vechileInformationModel == null)
                {
                    log.Info("Object is not supplied");
                    return await Task.FromResult(BadRequest("Data is not available or empty"));
                }
                else
                {
                    log.InfoFormat("Reigster Vechile for Driver {0}", vechileInformationModel.DriverId);
                    CreateVechileResponseModel reponse = await Task.FromResult(_registerVechileService.RegisterVehicle(vechileInformationModel));
                    log.InfoFormat("Reigster Vechile for Driver {0} is success", vechileInformationModel.DriverId);
                    return Created("SUCCESS",reponse);
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while creating the user : {0}", ex);
                return StatusCode(StatusCodes.Status500InternalServerError);

            }
        }

        [HttpPost]
        [Route("TrackLocation")]
        public async Task<IActionResult> TrackVechile([FromBody] VechileLocationModel vechileLocationModel)
        {
            try
            {
                if (vechileLocationModel == null)
                {
                    log.Info("Object is not supplied");
                    return await Task.FromResult(BadRequest("Data is not available or empty"));
                }
                else
                {
                    log.InfoFormat("Tracking vechile for driver {0} and his vechile is {1}", vechileLocationModel.DriverId, vechileLocationModel.VechileNumber);
                    DriverLocationResponseModel response = await Task.FromResult(_trackVechileLocation.TrackVechileLocation(vechileLocationModel));
                    log.InfoFormat("Tracking vechile for driver {0} and his vechile is {1} are success", vechileLocationModel.DriverId, vechileLocationModel.VechileNumber);
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while creating the user : {0}", ex);
                return StatusCode(StatusCodes.Status500InternalServerError);

            }
        }
        [HttpGet]
        [Route("GetLocationHistoryByDriverId/{DriverId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetLocationHistoryByDriverId(Int64 DriverId)
        {
            try
            {
                if (string.IsNullOrEmpty(DriverId.ToString()))
                {
                    log.Info("Driver Id is not supplied");
                    return await Task.FromResult(BadRequest("Driver Id cannot be empty"));
                }
                else
                {
                    log.InfoFormat("Getting location history for the vechile for driver id {0}", DriverId);
                    VechileLocationHistoryByDriverIdModel response = await Task.FromResult(_vechileLocationHistory.GetVechileLocationHistory(DriverId));
                    log.InfoFormat("Getting location history for the vechile for driver id {0} is success", DriverId);
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while creating the user : {0}", ex);
                return StatusCode(StatusCodes.Status500InternalServerError);

            }

        }
    }
}
