﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using static VechileTrackingRestAPI.Helper.ErrorCodeEnumeration;

namespace VechileTrackingRestAPI.Models.Response
{
    public class DriverInfoResponseModel
    {
        public string CustomerRelationshipNumber { get; set; }
        public HttpStatusCode StatusCode { get; set; }
        public string StatusDescription { get; set; }
    }

}