﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VechileTrackingRestAPI.Criteria
{
    public class UserRegisterCriteria
    {
        public string Name {get;set;}
        public Int64 Age { get; set; }
        public string Gender { get; set; }
        public string MobileNumber { get; set; }
    }
}