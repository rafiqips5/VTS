﻿using System;
#nullable disable

namespace VechileTrackingAPI.Models
{
    public partial class UserModel
    {

        public string UserId { get; set; }

        public string UserName { get; set; }

        public string UserPassword { get; set; }

        public string UserRoles { get; set; }

        public string UserEmailId { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
