﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace VechileTrackingRestAPI.Models.Response
{
    public class VechileLocationHistoryByDriverIdModel
    {
        public List<Location> DriverLocationHistoryData{ get; set; }
        public HttpStatusCode StatusCode { get; set; }
        public string StatusDescription { get; set; }
    }

    public class Location
    {
        public DateTime LocationDatetime { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }
}