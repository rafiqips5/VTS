﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using VechileTrackingAPI.Models;
using VechileTrackingAPI.Service;
using VechileTrackingRestAPI.Helper;
using VechileTrackingRestAPI.Models.Response;


namespace VechileTrackingAPI.Repository
{
    public class VechileLocationHistoryRepository : IVechileLocationHistory
    {

        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        VechileDBContext vechileDBContext = null;
        VechileLocationHistoryByDriverIdModel vechileLocationHistoryByDriverIdModel = null;
        public VechileLocationHistoryByDriverIdModel GetVechileLocationHistory(long DriverId)
        {
            try
            {
                vechileDBContext = new VechileDBContext();
                var vechileHistoryData = vechileDBContext.TblDriverLocations.Where(v => v.DriverId == DriverId).ToList();
                List<Location> locationList = new List<Location>();
                log.InfoFormat("location history count for the driver is {0}",locationList.Count);
                if (vechileHistoryData.Count > 0)
                {
                    foreach (var data in vechileHistoryData)
                    {
                        Location location = new Location();
                        location.Latitude = data.Latitude;
                        location.Longitude = data.Longitude;
                        location.LocationDatetime = data.DateTime;
                        locationList.Add(location);
                    }

                    log.InfoFormat("Location history for the vechile is tracked for driver: {0}",DriverId);
                    vechileLocationHistoryByDriverIdModel = new VechileLocationHistoryByDriverIdModel();
                    vechileLocationHistoryByDriverIdModel.DriverLocationHistoryData = locationList;
                    vechileLocationHistoryByDriverIdModel.StatusCode = HttpStatusCode.OK;
                    vechileLocationHistoryByDriverIdModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.SUCCESS.ToString();
           
                }
                else
                {
                    log.InfoFormat("No data found for the driver :{0}",DriverId);
                    vechileLocationHistoryByDriverIdModel = new VechileLocationHistoryByDriverIdModel();
                    vechileLocationHistoryByDriverIdModel.StatusCode = HttpStatusCode.NoContent;
                    vechileLocationHistoryByDriverIdModel.StatusDescription = "Journey not Started";
                    
                }
                return vechileLocationHistoryByDriverIdModel;
            }
            catch(Exception ex)
            {
                log.InfoFormat("Exeception Occured {0}", ex);
                vechileLocationHistoryByDriverIdModel = new VechileLocationHistoryByDriverIdModel();
                vechileLocationHistoryByDriverIdModel.StatusCode = HttpStatusCode.InternalServerError;
                vechileLocationHistoryByDriverIdModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.INNTERNAL_SERVER_ERROR.ToString();
                return vechileLocationHistoryByDriverIdModel;
            }

        }
    }
}
