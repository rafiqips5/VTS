﻿using VechileTrackingAPI.Models;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Service
{
    public interface ITrackVechileLocation
    {

        DriverLocationResponseModel TrackVechileLocation(VechileLocationModel vechileLocationModel);
    }
}
