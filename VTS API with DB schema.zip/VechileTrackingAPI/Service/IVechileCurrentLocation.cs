﻿using System;
using System.Threading.Tasks;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Service
{
    public interface IVechileCurrentLocation
    {
        VechileLocationByDriverIdModel GetCurrentLocationForVechile(Int64 DriverId);
    }
}
