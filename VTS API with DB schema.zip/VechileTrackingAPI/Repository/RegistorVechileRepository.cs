﻿using log4net;
using System;
using System.Linq;
using System.Net;
using System.Reflection;

using VechileTrackingAPI.Models;
using VechileTrackingAPI.Service;
using VechileTrackingRestAPI.Helper;
using VechileTrackingRestAPI.Models.Response;


namespace VechileTrackingAPI.Repository
{
    public class RegistorVechileRepository : IRegisterVechileService
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        VechileDBContext vechileDBContext = null;
        CreateVechileResponseModel createVechileResponseModel = null;

        public CreateVechileResponseModel RegisterVehicle(VechileInformationModel vechileInformationModel)
        {
            try
            {
                createVechileResponseModel = new CreateVechileResponseModel();
                if (string.IsNullOrEmpty(vechileInformationModel.DriverId.ToString()))
                {
                    log.Info("DriverId is empty, please enter the value.");
                    createVechileResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createVechileResponseModel.StatusDescription = "DriverId is empty, please enter the value.";
                    return createVechileResponseModel;
                }

                if (string.IsNullOrEmpty(vechileInformationModel.Brand))
                {
                    log.Info("Brand is empty, please enter the value");
                    createVechileResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createVechileResponseModel.StatusDescription = "Brand is empty, please enter the value.";
                    return createVechileResponseModel;
                }
                if (string.IsNullOrEmpty(vechileInformationModel.Model))
                {
                    log.Info("Vechile Model is empty, please enter the value.");
                    createVechileResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createVechileResponseModel.StatusDescription = "Vechile Model is empty, please enter the value.";
                    return createVechileResponseModel;
                }
                if (string.IsNullOrEmpty(vechileInformationModel.Number))
                {
                    log.Info("Vechile Number is empty, please enter the value.");
                    createVechileResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createVechileResponseModel.StatusDescription = "Vechile Number is empty, please enter the value.";
                    return createVechileResponseModel;
                }
                if (string.IsNullOrEmpty(vechileInformationModel.EngineChaseNumber))
                {
                    log.Info("EngineChaseNumber is empty, please enter the value.");
                    createVechileResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createVechileResponseModel.StatusDescription = "EngineChaseNumber is empty, please enter the value.";
                    return createVechileResponseModel;
                }
                if (string.IsNullOrEmpty(vechileInformationModel.PurchaseDate.ToString()))
                {
                    log.Info("EngineChaseNumber is empty, please enter the value.");
                    createVechileResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createVechileResponseModel.StatusDescription = "PurchaseDate is empty, please enter the value.";
                    return createVechileResponseModel;
                }
                if (string.IsNullOrEmpty(vechileInformationModel.VechileCondition))
                {
                    log.Info("VechileCondition is empty, please enter the value.");
                    createVechileResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createVechileResponseModel.StatusDescription = "VechileCondition is empty, please enter the value.";
                    return createVechileResponseModel;
                }

                vechileDBContext = new VechileDBContext();
                if(vechileDBContext.TblVechileInformations.Where(x=>x.Number == vechileInformationModel.Number).Count() >0)
                {
                    log.InfoFormat("Vechile Number : {0} is already registered.",vechileInformationModel.Number);
                    createVechileResponseModel.StatusCode = HttpStatusCode.BadRequest;
                    createVechileResponseModel.StatusDescription = "Vechile is already registered, please give the new vechile for registeration";
                    return createVechileResponseModel;
                }
                else
                {
                    // creating vechile for driver
                    vechileDBContext.TblVechileInformations.Add(vechileInformationModel);
                    vechileDBContext.SaveChanges();

                    log.InfoFormat("Vechile {0} is sucessfully registered for driver {1}",vechileInformationModel.Number,vechileInformationModel.Driver);
                    createVechileResponseModel.StatusCode = HttpStatusCode.Created;
                    createVechileResponseModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.SUCCESS.ToString();
                    return createVechileResponseModel;
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while creating the vechile {0}",ex);
                createVechileResponseModel.StatusCode = HttpStatusCode.InternalServerError;
                createVechileResponseModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.INNTERNAL_SERVER_ERROR.ToString();
                return createVechileResponseModel;
            }
        }
    }
}
