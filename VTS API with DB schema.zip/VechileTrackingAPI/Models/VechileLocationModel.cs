﻿using System;

#nullable disable

namespace VechileTrackingAPI.Models
{
    public partial class VechileLocationModel
    {
        public long DriverId { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public DateTime DateTime { get; set; }
        public string VechileNumber { get; set; }
        public long WatcherId { get; set; }
        public long LocationId { get; set; }

        public virtual DriverInformationModel Driver { get; set; }
        public virtual VechileInformationModel VechileNumberNavigation { get; set; }
    }
}
