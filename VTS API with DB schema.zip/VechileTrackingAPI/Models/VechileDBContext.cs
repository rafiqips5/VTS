﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using VechileTrackingAPI.Helper.Authentication;

#nullable disable

namespace VechileTrackingAPI.Models
{
    public partial class VechileDBContext : IdentityDbContext<ApplicationUser>
    {
        private string ConStr = string.Empty;
        public VechileDBContext()
        {
        }

        public VechileDBContext(DbContextOptions<VechileDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DriverInformationModel> TblDriverInformations { get; set; }
        public virtual DbSet<VechileLocationModel> TblDriverLocations { get; set; }
        public virtual DbSet<UserModel> TblUserMasters { get; set; }
        public virtual DbSet<VechileInformationModel> TblVechileInformations { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            if (!optionsBuilder.IsConfigured)
            {
                var config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
                ConStr = config["ConnectionStrings:ConnStr"];

                //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer(ConStr);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<DriverInformationModel>(entity =>
            {
                entity.HasKey(e => e.DriverId)
                    .HasName("PK_DriverInformation");

                entity.ToTable("TBL_DRIVER_INFORMATION");

                entity.HasIndex(e => e.MobileNumber, "TBL_DriverInformation_MobileNUmber")
                    .IsUnique();

                entity.Property(e => e.Address1).HasMaxLength(100);

                entity.Property(e => e.Address2).HasMaxLength(100);

                entity.Property(e => e.City)
                    .HasMaxLength(50)
                    .HasColumnName("city");

                entity.Property(e => e.Country)
                    .HasMaxLength(50)
                    .HasColumnName("country");

                entity.Property(e => e.DateTime).HasColumnType("datetime");

                entity.Property(e => e.Gender).HasMaxLength(50);

                entity.Property(e => e.LicenseNumber).HasMaxLength(50);

                entity.Property(e => e.LicenseValid).HasColumnType("datetime");

                entity.Property(e => e.MobileNumber).HasMaxLength(20);

                entity.Property(e => e.Name).HasMaxLength(50);

                entity.Property(e => e.State)
                    .HasMaxLength(50)
                    .HasColumnName("state");
            });

            modelBuilder.Entity<VechileLocationModel>(entity =>
            {
                entity.HasKey(e =>e.LocationId);

                entity.ToTable("TBL_DRIVER_LOCATION");

                entity.Property(e => e.DateTime).HasColumnType("datetime");

                entity.Property(e => e.Latitude)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Longitude)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.VechileNumber)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.Driver)
                    .WithMany()
                    .HasForeignKey(d => d.DriverId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DriverId");

                entity.HasOne(d => d.VechileNumberNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.VechileNumber)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_VechileNumber");
            });

            modelBuilder.Entity<UserModel>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("TBL_USER_MASTER");

                entity.Property(e => e.UserId)
                    .HasMaxLength(300)
                    .HasColumnName("UserID");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.UserEmailId)
                    .HasMaxLength(300)
                    .HasColumnName("UserEmailID");

                entity.Property(e => e.UserName).HasMaxLength(200);

                entity.Property(e => e.UserPassword).HasMaxLength(50);

                entity.Property(e => e.UserRoles).HasMaxLength(50);
            });

            modelBuilder.Entity<VechileInformationModel>(entity =>
            {
                entity.HasKey(e => e.Number)
                    .HasName("PK_VechileInformation");

                entity.ToTable("TBL_VECHILE_INFORMATION");

                entity.HasIndex(e => e.EngineChaseNumber, "UQ__TBL_Vech__23162888958F385F")
                    .IsUnique();

                entity.Property(e => e.Number).HasMaxLength(100);

                entity.Property(e => e.Brand).HasMaxLength(100);

                entity.Property(e => e.DateTime).HasColumnType("datetime");

                entity.Property(e => e.EngineChaseNumber).HasMaxLength(100);

                entity.Property(e => e.Model).HasMaxLength(100);

                entity.Property(e => e.PurchaseDate).HasColumnType("datetime");

                entity.Property(e => e.VechileCondition).HasMaxLength(50);

                entity.HasOne(d => d.Driver)
                    .WithMany(p => p.TblVechileInformations)
                    .HasForeignKey(d => d.DriverId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__DriverInfomation_DriverId");
            });

            OnModelCreatingPartial(modelBuilder);
            
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
