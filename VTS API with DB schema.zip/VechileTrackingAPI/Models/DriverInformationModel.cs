﻿using System;
using System.Collections.Generic;

#nullable disable

namespace VechileTrackingAPI.Models
{
    public partial class DriverInformationModel
    {
        public DriverInformationModel()
        {
            TblVechileInformations = new HashSet<VechileInformationModel>();
        }

        public long DriverId { get; set; }
        public string Name { get; set; }
        public int? Age { get; set; }
        public string Gender { get; set; }
        public string MobileNumber { get; set; }
        public string LicenseNumber { get; set; }
        public DateTime? LicenseValid { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual ICollection<VechileInformationModel> TblVechileInformations { get; set; }
    }
}
