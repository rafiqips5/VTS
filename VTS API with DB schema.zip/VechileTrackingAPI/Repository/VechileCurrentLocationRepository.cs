﻿using log4net;
using System;
using System.Linq;
using System.Net;
using System.Reflection;
using VechileTrackingAPI.Models;
using VechileTrackingAPI.Service;
using VechileTrackingRestAPI.Helper;
using VechileTrackingRestAPI.Models.Response;

namespace VechileTrackingAPI.Repository
{
    public class VechileCurrentLocationRepository : IVechileCurrentLocation
    {
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        VechileDBContext vechileDBContext = null;
        VechileLocationByDriverIdModel vechileLocationByDriverIdModel = null;
        public VechileLocationByDriverIdModel GetCurrentLocationForVechile(long DriverId)
        {
            try
            {
                log.InfoFormat("Getting current location for the vechile : {0}",DriverId);
                vechileDBContext = new VechileDBContext();
                var response = vechileDBContext.TblDriverLocations.Where(d => d.DriverId == DriverId).OrderByDescending
                    (d => d.DateTime).Take(1).ToList();
                if (response.Count > 0)
                {
                    log.InfoFormat("Curent location for the vechile is successfully tracked for driver : {0}",DriverId);
                    vechileLocationByDriverIdModel = new VechileLocationByDriverIdModel();
                    vechileLocationByDriverIdModel.Latitude = response[0].Latitude;
                    vechileLocationByDriverIdModel.Longitude = response[0].Longitude;
                    vechileLocationByDriverIdModel.StatusCode = HttpStatusCode.OK;
                    vechileLocationByDriverIdModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.SUCCESS.ToString();
                }
                else
                {
                    log.InfoFormat("No data found for driver : {0}",DriverId);
                    vechileLocationByDriverIdModel = new VechileLocationByDriverIdModel();
                    vechileLocationByDriverIdModel.StatusCode = HttpStatusCode.OK;
                    vechileLocationByDriverIdModel.StatusDescription = "Vechile not started journey";
                }
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Exception occured while processing data for drvierId : {0} Error : {1}",DriverId, ex);
                vechileLocationByDriverIdModel.StatusCode = HttpStatusCode.InternalServerError;
                vechileLocationByDriverIdModel.StatusDescription = ErrorCodeEnumeration.ResponseDescription.INNTERNAL_SERVER_ERROR.ToString();
            }
            return vechileLocationByDriverIdModel;
        }
    }
}
